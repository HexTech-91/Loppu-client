package dev.luminous;

import dev.luminous.api.events.eventbus.EventBus;
import dev.luminous.core.impl.FriendManager;
import dev.luminous.core.impl.ModuleManager;
import dev.luminous.core.impl.ShaderManager;
import net.fabricmc.api.ModInitializer;

/**
 * Minimal shim for the extracted Skybox module.
 *
 * In the original Loppu-client project this class is the mod entrypoint and
 * initializes every manager. The skybox extraction only needs the static
 * fields used by the (verbatim) Skybox / ShaderManager / ShaderModule code:
 *   - SHADER   : ShaderManager instance (SkyBox.renderSkybox() reads it)
 *   - MODULE   : ModuleManager instance (Module.enable/disable shows banners)
 *   - FRIEND   : FriendManager instance (ShaderModule.shouldRender() uses it)
 *   - EVENT_BUS: event bus (Module.enable/disable subscribes/unsubscribes)
 *
 * All other original functionality is intentionally omitted.
 */
public class Alien implements ModInitializer {
    public static final EventBus EVENT_BUS = new EventBus();
    public static ModuleManager MODULE;
    public static ShaderManager SHADER;
    public static FriendManager FRIEND;

    @Override
    public void onInitialize() {
        FRIEND = new FriendManager();
        MODULE = new ModuleManager();
        SHADER = new ShaderManager();
        SHADER.init();
    }
}
