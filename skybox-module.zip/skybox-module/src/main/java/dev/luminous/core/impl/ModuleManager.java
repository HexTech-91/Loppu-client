package dev.luminous.core.impl;

import dev.luminous.api.utils.Wrapper;
import dev.luminous.mod.Mod;
import dev.luminous.mod.modules.Module;
import dev.luminous.mod.modules.impl.render.SkyBox;
import java.util.ArrayList;
import java.util.Comparator;

/**
 * Minimal ModuleManager slice for the extracted Skybox module.
 *
 * In the original Loppu-client project this class registers every module of
 * the client (100+ modules) plus the toggle-banner / notification rendering.
 * The skybox extraction only needs:
 *   - addModule()               : registers the SkyBox module
 *   - getModules()              : module list accessor
 *   - showToggleBanner()        : called by Module.enable()/disable()
 *
 * Only the SkyBox registration is kept. All other original functionality is
 * intentionally omitted from this standalone module.
 */
public class ModuleManager implements Wrapper {
    private final ArrayList<Module> modules = new ArrayList<>();

    public ModuleManager() {
        this.init();
    }

    public void init() {
        this.addModule(new SkyBox());
        this.modules.sort(Comparator.comparing(Mod::getName));
    }

    public ArrayList<Module> getModules() {
        return this.modules;
    }

    public void addModule(Module module) {
        this.modules.add(module);
    }

    public Module getModuleByName(String string) {
        for (Module module : this.modules) {
            if (module.getName().equalsIgnoreCase(string)) {
                return module;
            }
        }
        return null;
    }

    public void showToggleBanner(Module module, boolean enabled) {
        // Banner/notification UI is part of the original client's HUD and is
        // intentionally not carried over. The interface is kept so the
        // verbatim Module.enable()/disable() code compiles unchanged.
    }
}
